(function(){
	angular
	.module('sliderApp')
	.directive('sliderDirective',sliderDirective);
	function sliderDirective($interval){
		var directive = {
			link: sliderLink,
			templateUrl: `app/slider/template/sliderTemplate.html`,
			restrict: `EA`
		};
		return directive;
		function sliderLink(scope,element,attrs){
			scope.index     = 0;
			scope.slideShow = [];
			let k           = 0;

			function addImages(){
				for(let i = 0 ; i < 3 ; i++){
					// console.log(k);
					scope.slideShow.push(slideImages[k]);
					k += 1;
				if (k === 6){
					k = 0;
				}
				}
				console.log(scope.slideShow);
			}

			addImages();

			function removeImages(){
				scope.slideShow = [];
			}

			scope.next = function(){
				if(scope.index >= scope.slideShow.length-1){
					removeImages();
					addImages();
					scope.index = 0;
				} else{
					scope.index += 1;
				}
			}

			scope.previous = function(){
				if(scope.index <= 0){
					removeImages();
					addImages();
					scope.index = scope.slideShow.length-1;
				} else{
					scope.index -= 1;
				}
			}

			scope.getImage = function(index){
				scope.index = index;
			}

			scope.$watch('index',function(){
				setImage();
			});

			$interval(function(){
				scope.next();
			},5000);

			// function timer(){

			// }

			function setImage(){
				for(let i = 0; i < 3; i++){
					if(scope.index === i){
						scope.slideShow[i].status = true;
					} else{
						scope.slideShow[i].status = false;
					}
				}
			}

		}
	}
	sliderDirective.$inject = ['$interval'];
})();
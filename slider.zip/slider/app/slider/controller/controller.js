(function(){
	angular
	.module('sliderApp')
	.controller('sliderCtrl',sliderCtrl);
		function sliderCtrl($rootScope){}
		sliderCtrl.$inject = ['$rootScope'];
})();
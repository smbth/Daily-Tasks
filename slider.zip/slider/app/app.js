(function(){
	angular
	.module('sliderApp',['ngAnimate']);
})();
			var slideImages = [
			{
				src:`css/images/1.jpg`,
				status:false
			},

			{
				src:`css/images/2.jpg`,
				status:false
			},

			{
				src:`css/images/3.jpg`,
				status:false
			},

			{
				src:`css/images/4.jpg`,
				status:false
			},

			{
				src:`css/images/5.jpg`,
				status:false
			},
			
			{
				src:`css/images/6.jpg`,
				status:false
			}];
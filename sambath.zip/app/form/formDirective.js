app.directive('userForm',['setUser','getUser','exchgData','$location',function(setUser,getUser,exchgData,$location){
	return{
		link: link,
		templateUrl: `app/form/formTemplate.html`
	}
	function link(scope,element,attr){
		let editUser;
		function init(){
			editUser = 
		}
	}
}]);
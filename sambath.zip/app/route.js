app.config(function($routeProvider){
	$routeProvider
	.when('/login',{
		template: `<log-in></log-in>`
	})
	.when('/tabularData',{
		// template: `Routed to table data`
		template: `<user-table></user-table>`
		// templateUrl: `app/table/tableTemplate.html`
		// `app/form/formTemplate.html`
		//`app/table/tableTemplate.html`
	})
	.when('/form',{
		template: `<user-form></user-form>`
		// templateUrl: `app/form/formTemplate.html`
	})
	.otherwise({
		redirectTo: `/login`
	});
});
app.directive('logIn',['userAuth','$location',function(userAuth,$location){
	return {
		link: auth,
		templateUrl: `app/login/loginTemplate.html`
	}

	function auth(scope,element,attr){
		scope.checkUser = function(){
			if(userAuth.validate(scope.user)){
				$location.path('/tabularData');
			}
			else{
				console.log("Log In Failed!");
			}
		}
	}
}]);
app.factory('userAuth',function(){
	return{
		validate: function(user){
			if(user.id === "user" && user.password === "pass"){
				return true;
			}
			else {
				return false;
			}
		}
	}
});
app.controller('formAppCtrl',function($scope){
	$scope.testValue = value;
});
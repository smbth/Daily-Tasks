/*
 *@desc chosen directive for use in myApp under feathersoft(fs)
 *@author sambath
 *@example <div fs-myapp-chosen></div>
 *@doubt scope isolation!,controller as,asynchronous nature of js 
 */
 (function(){
 	angular
 	.module('myApp')
 	.directive('fsMyappChosen',directive);
 	function directive(){
 		let directive = {
 			link        : link,
 			templateUrl : `app/chosen/template/chosen.template.html`,
 			restrict    : `EA`
 		};
 		return directive;
 		function link(scope,element,attrs){
 			console.log("Link Contains Business Logic");
 			scope.dropDownItems = [`Category 1`,`Category 2`,`Category 3`];
 			scope.selectedItems = [];
 			// scope.name = `sambath`;
 			// console.log(scope.name);
 		}
 	}
 })();
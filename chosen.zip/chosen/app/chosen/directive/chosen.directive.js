/*
 *@desc chosen directive for use in myApp under feathersoft(fs)
 *@author sambath
 *@example <div fs-myapp-chosen></div>
 *@doubt scope isolation!,controller as,asynchronous nature of js 
 */
 (function(){
 	angular
 	.module('myApp')
 	.directive('fsMyappChosen',directive);
 	function directive(){
 		let directive = {
 			link        : link,
 			templateUrl : `app/chosen/template/chosen.template.html`,
 			restrict    : `EA`
 		};
 		return directive;
 		function link(scope,element,attrs){
 			console.log("Link Contains Business Logic");

 			scope.itemCount = 0;
 			scope.dropDown = true;
 			let selectedList = [];
 			scope.chosenList = [];
 			scope.selectedItem = null;

 			scope.toggleDrop = function () {
 			    console.log('toggleDrop!');
 			    scope.dropDown = !scope.dropDown;
 			    if (!scope.dropDown) {
 			        prepareResult();
 			    }
 			}


 			scope.toggleSelection = function (id) {
 			    scope.config.data[id].selected = !scope.config.data[id].selected;
 			   	    countItems();
 			}

 			function prepareResult() {
 			    if (scope.config.type === 'multi' || scope.config.type === 1) {
 			        selectedList.length = 0;
 			        for (let i = 0; i < scope.config.data.length; i++) {
 			            if (scope.config.data[i].selected === true) {
 			                selectedList.push(scope.config.data[i]);
 			                // console.log(selectedList);
 			            }
 			        }
 			        console.log(selectedList);
 			    } else if(scope.config.type === 'single' || scope.config.type === 0) {
 			        console.log(scope.selectedItem);
 			    }

 			}

 			function countItems() {
 			    scope.itemCount = 0;
 			        for (let i = 0; i < scope.config.data.length; i++) {
 			            if (scope.config.data[i].selected === true) {
 			                scope.itemCount++;
 			            }
 			        }
 			        // console.log(scope.itemCount);
 			}

 			scope.selectItem = function (item) {
 			        scope.selectedItem = item;
 			        scope.toggleDrop();
 			}

 			}


 		}
 	}

 })();
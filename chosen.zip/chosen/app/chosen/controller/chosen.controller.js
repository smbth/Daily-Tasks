/*
 *@desc controller
 *@author sambath
 */
 (function(){
 	angular
 	.module('myApp')
 	.controller('chosenController',controller);
 	function controller($scope){
 		// $scope.name = "sam";
 		$scope.config = {
 		    id: 2,
 		    type: 1,
 		    tittle: 'Filter Options...',
 		    // data: [
 		    //     "Option0","Option1","Option2","Option3","Option4","Option5","Option6","Option7","Option8","Option9","Option10","Option11","Option12","Option13","Option14","Option15","Option16","Option17","Option18","Option19","Option20","Option21","Option22","Option23"
 		    // ]
 		    data : [
 		        {
 		            text: 'Option 1',
 		            value: 'option1',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 2',
 		            value: 'option2',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 3',
 		            value: 'option3',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 4',
 		            value: 'option4',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 5',
 		            value: 'option5',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 6',
 		            value: 'option6',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 7',
 		            value: 'option7',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 8',
 		            value: 'option8',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 9',
 		            value: 'option9',
 		            selected: false
 		        },
 		        {
 		            text: 'Option 10',
 		            value: 'option10',
 		            selected: false
 		        }
 		    ]
 		};

 	}
 	controller.$inject = ['$scope'];
 })();
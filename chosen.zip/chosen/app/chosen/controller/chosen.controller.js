/*
 *@desc controller
 *@author sambath
 */
 (function(){
 	angular
 	.module('myApp')
 	.controller('chosenController',controller);
 	function controller($scope){
 		// $scope.name = "sam";
 	}
 	controller.$inject = ['$scope'];
 })();
/**
 *@desc myApp to embed the custom chosen-directive
 *@author sambath
 *@example
 */
(function(){
	angular.module('myApp',[]);
})();
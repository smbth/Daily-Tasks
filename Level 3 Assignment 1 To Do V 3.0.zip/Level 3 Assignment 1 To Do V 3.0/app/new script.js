/*
* @des: to do App
* @author: sambath
*/
var todoArray=[];
loadArray();
var menuFlag; // Menu Flag Values: A-All tasks, T-To be done tasks, C-completed tasks
var allbt  = document.getElementById("all");
var todobt = document.getElementById("todo");
var compbt = document.getElementById("comp");
window.addEventListener("load",filterFunction('A'));

add_btn.addEventListener("click",function(){
	var inpt = document.getElementById('task');
    if(inpt.value != ''){
	    var taskString = inpt.value;
	    inpt.value     = "";
		    todoArray.push({taskValue:taskString,status:false});
		    localStorage.setItem('todo',JSON.stringify(todoArray));
		    refresh();
		    display();
    }
});

// Load the array with JSON content.
function loadArray(){
	todoArray = JSON.parse(localStorage.getItem('todo'));
}

// Refresh Function
function refresh(){
	document.getElementById("content").innerHTML = "";
}

//Filter Function
function filterFunction(flag){
	menuFlag = flag;
	console.log(menuFlag);
	display();
}

//Display Function
function display(){
	refresh();
	var ulist=document.createElement("ul");
	for(let i = 0;i < todoArray.length;i++){
		var list=document.createElement("li");
		list.setAttribute("align","center");
		var span         = document.createElement("span");
		var statusButton = document.createElement("button");
		var deleteButton = document.createElement("button");
		statusButton.setAttribute("onclick","changeStatus("+i+")");
		deleteButton.setAttribute("onclick","deleteTask("+i+")");
		deleteButton.setAttribute("title","Delete!");
		deleteButton.innerHTML = "&#9747";
		
		if(menuFlag==='A'){
			allbt.setAttribute("class", "bt_active");
			todobt.setAttribute("class", "");
			compbt.setAttribute("class", "");
			if(todoArray[i].status == false){
				statusButton.innerHTML = "&#10003;";
				statusButton.setAttribute("title","Done!");
			}
			else{
				statusButton.innerHTML = "&#8634;";
				statusButton.setAttribute("title","Redo!");
				list.setAttribute("class","strikedText");
			}
			span.append(statusButton);
			span.append(deleteButton);
			list.append(todoArray[i].taskValue);
			list.append(span);
			ulist.append(list);
		}

		if(menuFlag === 'T'){
			allbt.setAttribute("class", "");
			todobt.setAttribute("class", "bt_active");
			compbt.setAttribute("class", "");
			if (todoArray[i].status === false){
				statusButton.innerHTML = "&#10003;";
				statusButton.setAttribute("title","Done!");
				span.append(statusButton);
				span.append(deleteButton);
				list.append(todoArray[i].taskValue);
				list.append(span);
				ulist.append(list);
			}
		}

		if(menuFlag === 'C'){

			allbt.setAttribute("class", "");
			todobt.setAttribute("class", "");
			compbt.setAttribute("class", "bt_active");
			if (todoArray[i].status === true) {
				statusButton.innerHTML = "&#8634;"
				statusButton.setAttribute("title","Redo!");
				list.setAttribute("class","strikedText");
				span.append(statusButton);
				span.append(deleteButton);
				list.append(todoArray[i].taskValue);
				list.append(span);
				ulist.append(list);
			}
		}
	}
	console.log(ulist);
	document.getElementById("content").append(ulist);
}

//Status Changer,trigerred by onclick
function changeStatus(i){
	if (todoArray[i].status === false){
		todoArray[i].status = true;
	}
	else{
		todoArray[i].status = false;
	}
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}

// Task Deleter, trigerred by onclick
function deleteTask(i){
	todoArray.splice(i,1);
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}

app.directive('userTable',['getUser',function(getUser){
	return{
		link: showUsers,
		templateUrl: `app/table/simpleTableTemplate.html`
	}
	function showUsers(scope,element,attr){
		scope.userList = getUser.get();
	}
}]);
app.directive('userTable',['getUser','$location',function(getUser,$location){
	return{
		link: showUsers,
		templateUrl: `app/table/simpleTableTemplate.html`
	}
	function showUsers(scope,element,attr){
		scope.userList = getUser.get();
		scope.editUser = function(index){
			console.log(index);
			$location.path('/form');
		}
	}
}]);
app.directive('userTable',[function(){
	return{
		templateUrl: `app/table/tableTemplate.html`
	}
}]);
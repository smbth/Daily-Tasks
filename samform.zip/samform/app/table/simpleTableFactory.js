app.factory('getUser',function(){
	return {
		get: function(){
			let userList = JSON.parse(localStorage.getItem('userJSON'));
			return userList;
		}
	}
});
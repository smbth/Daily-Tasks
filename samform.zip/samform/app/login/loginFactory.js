app.factory('userAuth',function(){
	return{
		validate: function(user){
			if(user.id === "user" && user.password === "pass"){
				return true;
			}
			else {
				alert("Invalid User");
				return false;
			}
		}
	}
});
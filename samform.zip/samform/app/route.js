app.config(function($routeProvider){
	$routeProvider
	.when('/login',{
		template: `<log-in></log-in>`
	})
	.when('/form',{
		template: `<user-form></user-form>`
	})
	.when('/tabularData',{
		template: `<user-table></user-table>`
		// template: `form Submitted`
	})
	.otherwise({
		redirectTo: `/login`
	});
});
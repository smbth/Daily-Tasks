app.factory('setUser',function(){
	return{
		save: function(user){
			let userList = JSON.parse(localStorage.getItem('userJSON'));
			if(!userList){
				userList = [];
				localStorage.setItem('userJSON',JSON.stringify(userList));
			}
				userList.push(user);
				localStorage.setItem('userJSON',JSON.stringify(userList));
			return userList;
		}
	}
});
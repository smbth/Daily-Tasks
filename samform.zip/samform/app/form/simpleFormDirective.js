app.directive('userForm',['setUser','$location',function(setUser,$location){
	return{
		link: keepUser,
		templateUrl: `app/form/simpleFormTemplate.html`
	}
	function keepUser(scope, element, attr){
		scope.keepUser = function(){
			console.log("touched user form");
			newUserList = setUser.save(scope.user);
			console.log(newUserList);
			$location.path('/tabularData');
			scope.user="";
		}
	}
}]);
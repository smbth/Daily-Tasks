app.directive('userForm',['getUser','setUser','exchgData','$location',function(getUser,setUser,exchgData,$location){
	return {
		link: link,
		templateUrl: `app/form/simpleFormTemplate.html`
	}

	function link(scope,element,attr){
		// let editUser;
		// function init(){
		// 	editUser = exchgData.get('user');
		// 	if(editUser){
		// 		scope.userList = editUser.userList;
		// 		scope.user = editUser.userList;
		// 	}
		// 	else{
		// 		scope.userList = getUser.get();
		// 		scope.user ={
		// 			name   : ''
		// 		}
		// 	}
		// }
		// // init();
		scope.addUSer = function(status){
			console.log('in register function');
			if(!editUser) scope.userList.push(scope.user);
			if(setUser.save(scope.userList)){
				// init();
				if(status === true){
					$location.path('/form');
				}
			}
		}
	}
}]);
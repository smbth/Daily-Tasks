// get user
app.factory('getUser',function(){
	return{
		get: function(){
			let userList = JSON.parse(localStorage.getItem('userList'));
			if(userList){
				return userList;
			}
			else{
				return [];
			}
		}	
	}
});

// inter process communication, for communication between table and form templates
app.factory('exchgData',function(){
	let data = {};
	return{
		get: get,
		set: set
	}

	function get(key){
		try{
			return data[key];
		}finally{
			data = {};
		}
	}

	function set(key,value){
		data[key] = value;
	}
});

// register user
app.factory('setUser',['getUser',function(getUser){
	let userList = getUser.get();
	return{
		save: function(user){
			if(Array.isArray(user)){
				userList = user;
			}
			else{
				userList.push(user);
			}
			localStorage.setItem('userList',JSON.stringigfy(userList));
		console.log(userList);
			return true;
		}
	}
}]);

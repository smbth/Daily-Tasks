app.controller('formAppCtrl',function($scope){
	$scope.testValue = value;
	// $scope.userArray = [];
	$scope.buttonValue = "Save";
	// console.log(userArray)
});
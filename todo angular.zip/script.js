var myApp =angular.module("todo",[]);

myApp.controller("cntrlR", function($scope){
	// array of objects to store tasks and their status
	$scope.taskList = [];
	if(localStorage.getItem('localTaskList')!=null){
		$scope.taskList = JSON.parse(localStorage.getItem('localTaskList'));
	}

	// Adding new task
	$scope.addTask = function(){
		$scope.taskList.push({value:$scope.taskValue,status:false});
		$scope.taskValue="";
		$scope.saveList();
		// $scope.orderBy($scope.flag);
	};

	// changing the status of a task
	$scope.changeStatus = function(i){
		$scope.taskList[i].status = !$scope.taskList[i].status;
		console.log(i);
		$scope.saveList();
		// $scope.checkedStatus = $scope.taskList[i].status;

		// $scope.orderBy($scope.flag);
	};

	// deleting a task
	$scope.deleteTask = function(i){
		$scope.taskList.splice(i,1);
		$scope.saveList();
		// $scope.orderBy($scope.flag);
	};

	// saving the task list to JSON
	$scope.saveList = function(){
		localStorage.setItem('localTaskList',JSON.stringify($scope.taskList));
		$scope.taskList = JSON.parse(localStorage.getItem('localTaskList'));
	};

	// filter function
	$scope.orderBy = function(f){
		$scope.flag = f;
	};

	$scope.checkedStatus(i){
		return $scope.taskList[i].status;
	}
});
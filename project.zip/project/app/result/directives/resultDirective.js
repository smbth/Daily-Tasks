(function(){
	angular
	.module('quizApp')
	.directive('resultDirective',resultDirective);
	function resultDirective(storeService){
		var directive = {
			link: resultLink,
			templateUrl: `app/templates/resultTemplate.html`
		}
		return directive;
		function resultLink(scope,element,attrs){
			scope.marks = storeService.get('marks');
		}
	}
	resultDirective.$inject = ['storeService'];
})();
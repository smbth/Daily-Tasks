(function(){
	angular
	.module('quizApp')
	.directive('allQuestionsDirective',allQuestionsDirective);
	function allQuestionsDirective(storeService,questionSelectorService){
		var directive = {
			link: questionLink,
			templateUrl: `app/templates/questionTemplate.html`
		};
		return directive;
		function questionLink(scope,element,attrs){
			let i = 0;
	
			
			// [
			// 	{i: 0,q:"Click option 3",s:"General Knowledge",o:['option1','option2','option3','option4'],a:"option3",m:""},
			// 	{i: 1,q:"Click option 4",s:"History",o:['option1','option2','option3','option4'],a:"option4",m:""}
			// ];

			// json explanation: i - index, q - question, s - subject, o - options, a - answer, m -marked answer
			// let topics = storeService.get('topics');
			// console.log(topics);
			var qList = [
				[{i: 0,q:"Click option 3",s:"General Knowledge",o:['option1','option2','option3','option4'],a:"option3",m:""}],
				[{i: 1,q:"Click option 4",s:"History",o:['option1','option2','option3','option4'],a:"option4",m:""}]
			];
			let topics =  storeService.get('topics');
			var questionsList = [];
			angular.forEach(topics,function(topic){
				questionsList.push(qList[topic]);
			});
			console.log(questionsList);
			scope.questions = questionsList;
			console.log(scope.questions);

			function setQuestion(){
				scope.question = scope.questions[i];	
			}
			setQuestion();
			scope.previousQ = function(){
				if(i>0){
					--i;
					setQuestion();
				
				}else{
					
				}
			};
			scope.nextQ = function(){
				if(i<(scope.questions.length-1)){
					++i;
					setQuestion();
				}else{
					
				}
			};
			scope.finishQ = function(){
				console.log("Answers are:");
				angular.forEach(scope.questions,function(question){
					// question.m = "";
					console.log(question.m);
				})

			};
		}
	}
	allQuestionsDirective.$inject = ['storeService','questionSelectorService'];
})();
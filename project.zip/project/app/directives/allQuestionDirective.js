// no question Number
(function(){
	angular
	.module('quizApp')
	.directive('allQuestionsDirective',allQuestionsDirective);
	function allQuestionsDirective(storeService,questionSelectorService,$location){
		var directive = {
			link: questionLink,
			templateUrl: `app/templates/questionTemplate.html`
		};
		return directive;
		function questionLink(scope,element,attrs){
			let i = 0;
			scope.num = i+1;
			// json explanation: i - index, q - question, s - subject, o - options, a - answer, m -marked answer
			
			let quest = JSON.parse(localStorage.getItem('myJSON'));
			let topics = storeService.get('topics');
			let unAnsweredList = storeService.get('unAnsweredList');
			if(unAnsweredList == undefined){
				console.log("unAnsweredList is undefined");
				
			}
			// change questionListS to toAnswerList
			var questionListS = [];
			angular.forEach(topics,function(topic){
				questionListS = questionListS.concat(quest[topic]);
			});
			scope.questions = questionListS;

			function setQuestion(){
				scope.question = scope.questions[i];	
			}
			setQuestion();
			scope.previousQ = function(){
				if(i>0){
					--i;
					setQuestion();
				
				}else{
					
				}
				scope.num = i+1;
			};
			scope.nextQ = function(){
				if(i<(scope.questions.length-1)){
					++i;
					setQuestion();
				}else{
					
				}
				scope.num = i+1;
			};
			scope.finishQ = function(){
				let unAnsweredList = []
				let marks = 0;
				// console.log("Answers are:");
				angular.forEach(scope.questions,function(question){
					// question.m = "";
					// console.log(question.m);
					if(question.m == ""){
						unAnsweredList.push(question);
					}
					else{
						if(question.m == question.a){
							marks+=1;
						}

					}
				})
				if(unAnsweredList.length>0){
					console.log("questions are pending!");
					// route to skipped question view
				}else{
					console.log(marks);
					storeService.set('marks',marks);
					$location.path('/result');
					// route to result page
				}

			};
		}
	}
	allQuestionsDirective.$inject = ['storeService','questionSelectorService','$location'];
})();
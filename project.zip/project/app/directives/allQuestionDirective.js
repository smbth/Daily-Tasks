(function(){
	angular
	.module('quizApp')
	.directive('allQuestionsDirective',allQuestionsDirective);
	function allQuestionsDirective(){
		var directive = {
			link: questionLink,
			templateUrl: `app/templates/questionTemplate.html`
		};
		return directive;
		function questionLink(scope,element,attrs){

		}
	}
})();
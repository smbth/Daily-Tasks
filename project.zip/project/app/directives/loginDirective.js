(function(){
	angular
	.module('quizApp')
	.directive('loginDirective',loginDirective);
	function loginDirective(authentication,$rootScope,$location){
		var directive = {
			link: loginLink,
			// template: "login is here!",
			templateUrl:`app/templates/loginTemplate.html`,
			restrict: 'EA'
		};
		return directive;

		function loginLink(scope,element,attrs){
			// scope.user="";
			scope.user = {
				userName:'',
				passWord:''
			}
			scope.authenticate = function(){
				if(authentication.checkUser(scope.user)){
					$rootScope.$broadcast('login');
					$location.path('/selectSubject');
				}
				else{
					// $location.path('/login');
				}
			}
		}
	}
	loginDirective.$inject = ['loginAuthenticateService','$rootScope','$location'];
})();
(function(){
	angular
	.module('quizApp')
	.directive('selectSubjectDirective',selectSubjectDirective);
	function selectSubjectDirective($location){
		var directive = {
			link: subjectLink,
			templateUrl: `app/templates/subjectTemplate.html`
		};
		return directive;
		function subjectLink(scope,element,attrs){
			scope.subjects = [
				{'name':'Computing'},
				{'name':'Physics'},
				{'name':'Mathematics'},
				{'name':'Chemistry'},
				{'name':'Biology'},
				{'name':'History'},
				{'name':'Geography'},
				{'name':'Law'}
			];
			  var selectedSubjects = {};
			  var subjectArray = [];
			  var calculateSomeSelected = function() {
			    scope.someSelected = Object.keys(selectedSubjects).some(function (key) {
			      return selectedSubjects[key];
			    });
			  };
			  
			  scope.formData = {
			    selectedSubjects: selectedSubjects
			  };
			  
			  scope.checkboxChanged = calculateSomeSelected;
			  scope.addSubject = function(){
			        angular.forEach(scope.subjects,function(subject){
			           if(selectedSubjects[subject.name]){
			            subjectArray.push(subject.name);
			           }
			        });
			        //subjectArray = [];
			        // angular.forEach(subjectArray,function(){
			        // 	subjectArray.pop();
			        // });
			        // subjectArray.splice(0,subjectArray.length);
			        console.log(subjectArray);
			  }
			  scope.reset = function(){
			  	// $location.path('/selectSubject');
			  	scope.someSelected = false;
			  	subjectArray = [];
			  	//subjectArray.splice(0,subjectArray.length);
			    console.log(subjectArray);
			  }
		}
	}
	selectSubjectDirective.$inject = ['$location'];

})();
/*
reset and addSubjects not working properly
*/
(function(){
	angular
	.module('quizApp')
	.directive('selectSubjectDirective',selectSubjectDirective);
	function selectSubjectDirective($location,storeService){
		var directive = {
			link: subjectLink,
			templateUrl: `app/templates/subjectTemplate.html`
		};
		return directive;
		function subjectLink(scope,element,attrs){
			scope.subjects = [
				{'name':'General Knowledge','index':0},
				{'name':'Gadgets','index':1},
				{'name':'Geography','index':2}
			];
			var subjectArray = [];
			  var selectedSubjects = {};
			  scope.formData = { selectedSubjects: selectedSubjects };
			  
			  scope.checkboxChanged = function() {
			    scope.someSelected = Object.keys(selectedSubjects).some(function(key) {
			      return selectedSubjects[key];
			    });
			  };
			  scope.addSubject = function(){
			        angular.forEach(scope.subjects,function(subject){
			           if(selectedSubjects[subject.index]){
			            subjectArray.push(subject.index);
			            storeService.set('topics',subjectArray);
			            $location.path('/allQuestions');
			           }
			        });
			  };

			  scope.reset = function(){
			  	angular.forEach(scope.subjects,function(subject){
				  	if(selectedSubjects[subject.index]){
				  		selectedSubjects[subject.index] = false;
				  	}	
			  	});
			  	scope.someSelected = false;
			  	// console.log(storeService.get('topics'));
			  };
		}
	}
	selectSubjectDirective.$inject = ['$location','storeService'];

})();
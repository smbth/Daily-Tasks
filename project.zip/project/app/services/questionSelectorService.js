// a common service for selecting between all questions and skipped ones
(function(){
	angular
	.module('quizApp')
	.factory('questionSelectorService',questionSelectorService);
	function questionSelectorService(){
		var qsService = {
			selection: selection
		}
		return qsService;
			var questions = [
				{i: 0,q:"Click option 3",s:"General Knowledge",o:['option1','option2','option3','option4'],a:"option3",m:""},
				{i: 1,q:"Click option 4",s:"History",o:['option1','option2','option3','option4'],a:"option4",m:""}
			];
			var qArray = [];
		// qType - question type
		// qType - true -skipped questions, false - allQuestions Questions
		function selection(qType){
			return questions;

			// if(qType == true){
			// 	angular.forEach(questions,function(question){
			// 		if(question.m=""){
			// 			qArray.push(question);
			// 		}
			// 	})
			// 	return qArray;
			// }else{
			// 	return questions;
			// }
		}
	}
})();
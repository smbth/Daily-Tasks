// a common service for selecting between all questions and skipped ones
(function(){
	angular
	.module('quizApp')
	.factory('questionSelectorService',questionSelectorService);
	function questionSelectorService(){
		var qsService = {
			selection: selection
		}
		return qsService;
		function selection(){

		}
	}
})();
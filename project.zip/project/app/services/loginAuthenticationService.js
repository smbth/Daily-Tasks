(function(){
	angular
	.module('quizApp')
	.factory('loginAuthenticateService',loginAuthenticateService);
	function loginAuthenticateService(){
		var service = {
			checkUser: checkUser
		};
		return service;
		function checkUser(user){
			if(user.userName === "student" && user.passWord === "key123"){
				return true;	
			}else{
				return false;
			}
		}
	}
})();
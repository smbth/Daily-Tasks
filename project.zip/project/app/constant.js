// each sub Array is a category
var quizQuestions = [
	[
		{"i":0,"q":"What is the name of the Jewish New Year?","o":["Rosh Hashanah","Elul","New Year","Succoss"],"a":"Rosh Hashanah","m":""},
		{"i":1,"q":"What do the letters of the fast food chain KFC stand for?","o":["Kibbled Freaky Cow","Kentucky Fresh Chees","Kentucky Fried Chicken","Kiwi Food Cut"],"a":"Kentucky Fried Chicken","m":""},
		{"i":2,"q":"Where is Apple Inc. headquartered?","o":["Redwood City, California","Cupertino, California","Redmond, Washington","Santa Monica, CA"],"a":"Cupertino, California","m":""},
		{"i":3,"q":"What did the Spanish autonomous community of Catalonia ban in 2010, that took effect in 2012?","o":["Mariachi","Bullfighting","Flamenco","Fiestas"],"a":"Bullfighting","m":""},
		{"i":4,"q":"What is the name given to Indian food cooked over charcoal in a clay oven?","o":["Biryani","Pani puri","Tiki masala","Tandoori"],"a":"Tandoori","m":""}
	],
	[
		{"i":0,"q":"What are the base station trackers used for the HTC Vive called?","o":["Motion","Lighthouse","Constellation","Trackers"],"a":"Lighthouse","m":""},
		{"i":1,"q":"The term battery to describe an electrical storage device was coined by?","o":["Nikola Tesla","Luigi Galvani","Alessandro Volta","Benjamin Franklin"],"a":"Benjamin Franklin","m":""},
		{"i":2,"q":"Which buzzword did Apple Inc. use to describe their removal of the headphone jack?","o":["Innovation","Revolution","Courage","Bravery"],"a":"Courage","m":""},
		{"i":3,"q":"Which of the following is the standard THX subwoofer crossover frequency?","o":["80Hz","70Hz","90Hz","100Hz"],"a":"80Hz","m":""},
		{"i":4,"q":"Which of the following cellular device companies is NOT headquartered in Asia?","o":["Nokia","LG Electronics","Samsung","HTC"],"a":"Nokia","m":""}
	],
	[
		{"i":0,"q":"Gibraltar, located just south of the Iberian peninsula, is a territory of which West Europe country?","o":["Portugal","Spain","United Kingdom","France"],"a":"United Kingdom","m":""},
		{"i":1,"q":"What is the capital of Senegal?","o":["Nouakchott","Conakry","Dakar","Monrovia"],"a":"Dakar","m":""},
		{"i":2,"q":"What is the capital of South Korea?","o":["Pyongyang","Seoul","Taegu","Kitakyushu"],"a":"Seoul","m":""},
		{"i":3,"q":"What is the capital of Indonesia?","o":["Medan","Palembang","Jakarta","Bandung"],"a":"Jakarta","m":""},
		{"i":4,"q":"Which of the following Japanese islands is the biggest?","o":["Honshu","Hokkaido","Shikoku","Kyushu"],"a":"Honshu","m":""}
	]

]

var myJSON = JSON.stringify(quizQuestions);
localStorage.setItem('myJSON',myJSON);
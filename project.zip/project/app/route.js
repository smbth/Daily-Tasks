(function(){
	angular.module('quizApp')
	.run(['$rootScope','$location','loginAuthenticateService',function($rootScope,$location,loginAuthenticateService){
		$rootScope.$on('$routeChangeStart',function(event,nextRoute, currentRoute){
			if(!nextRoute.permission){
				if(!loginAuthenticateService.isLogged()){
					$location.path('/login');
				}
			}else if(loginAuthenticateService.isLogged() && nextRoute.$$route.originalPath === '/login'){
					$location.path('/selectSubject');
				}
		});
	 }])
	.config(['$routeProvider',function($routeProvider){
		$routeProvider
		.when('/login',{
			template: `<div login-directive=""></div>`,
			permission: true

		})
		.when('/selectSubject',{
			template: `<div select-subject-directive=""></div>`
		})
		.when('/allQuestions',{
			template: `<div all-questions-directive=""></div>`
		})
		.when('/result',{
			template: `<div result-directive=""></div>`
		})
		.otherwise({
			redirectTo: '/login'
		});
	}]);
})();
(function(){
	angular.module('quizApp')
	// .run();
	.config(['$routeProvider',function($routeProvider){
		$routeProvider
		.when('/login',{
			template: `<div login-directive=""></div>`

		})
		.when('/selectSubject',{
			// template:`select subject`
			template: `<div select-subject-directive=""></div>`
		})
		.when('/allQuestions',{
			template: `you entered to Questions`
			// template: `<div all-questions-directive=""></div>`
		})
		.when('/skippedQuestions',{
			// consider: https://codepen.io/danshields/pen/zqdgER
			template: `<div skipped-questions-directive=""></div>`
		})
		.when('/skippedWarning',{
			// when last questions next button is clicked go to warning page describing skipped questions from there go to '/skippedQuestions'
			template: `<div skipped-warning-directive=""></div>`
		})
		.when('/result',{
			//if all questions are attempted display result
			template: `<div result-directive=""></div>`
		})
		.otherwise({
			redirectTo: '/login'
		});
	}]);
})();
(function(){
	angular.module('quizApp')
	.controller('mainController',mainController);
	function mainController($rootScope){
		$rootScope.var = "quiz app started!"
	}
	mainController.$inject = ['$rootScope'];
})();

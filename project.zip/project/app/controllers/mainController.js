(function(){
	angular.module('quizApp')
	.controller('mainController',mainController);
	function mainController($rootScope,$scope,$location,loginAuthenticateService){
		// $rootScope.var = "quiz app started!"
		$scope.isLogged = loginAuthenticateService.isLogged();
		$scope.logout = function(){
			loginAuthenticateService.logout();
			$scope.isLogged = false;
			$location.path('/login');
		}
		$rootScope.$on('login',function(){
			$scope.isLogged = true;
		});
	}
	mainController.$inject = ['$rootScope','$scope','$location','loginAuthenticateService'];
})();

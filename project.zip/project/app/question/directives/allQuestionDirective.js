(function(){
	angular
	.module('quizApp')
	.directive('allQuestionsDirective',allQuestionsDirective);
	function allQuestionsDirective(storeService,$location){
		var directive = {
			link: questionLink,
			templateUrl: `app/templates/questionTemplate.html`,
			restrict: 'EA'
		};
		return directive;
		function questionLink(scope,element,attrs){
			scope.list = {
				finish:false,
				skipped:false
			};
			// i -question number
			let i      = 0;
			let index  = 1;
			// json explanation: i - index, q - question, o - options, a - answer, m -marked answer
			// loading all quesions from our json
			let quest  = JSON.parse(localStorage.getItem('myJSON'));
			let topics = storeService.get('topics');
			if(!topics){
				$location.path('/selectSubject');
			}
			// array of questions from selected subjects
			var questionListS = [];
			angular.forEach(topics,function(topic){
				questionListS = questionListS.concat(quest[topic]);
			});
			
			// adding question number
			
			angular.forEach(questionListS,function(listItem){
				listItem.i =  index;
				index      += 1;
			})


			// traversing questions starts here
			scope.questions = questionListS;
			// console.log(scope.questions);

			function setQuestion(){
				scope.question = questionListS[i];
				console.log(scope.question);
			}

			setQuestion();

			scope.nextQ = function(){
				var start  =  i;
				i         += 1;
				if(i === questionListS.length-1){
					scope.list.finish = true;
				}
				if(i === questionListS.length){
					i = 0;
				}
				if(scope.list.skipped){
					var j = i;
					while(true){
						if(questionListS[j].m == ""){
							i = j;
							setQuestion();
							break;
						}
						if(j === start){
							break;
						}
						if(j === questionListS.length-1){
							j = 0;
						}
						j += 1;
					}
				}else{
					setQuestion();
				}
			};

			scope.previousQ = function(){
				var start = i;
				i         -=1;
				if(i<0){
					scope.list.finish = true;
					i = questionListS.length-1;
				}
				if(scope.list.skipped){
					var j = i;
					while(true){
						if(questionListS[j].m == ""){
							i = j;
							setQuestion();
							break;
						}
						if(j === start){
							break;
						}
						j -= 1;
						if(j <= 0){
							j = questionListS.length-1;
						}
					}
				}
				else{
						setQuestion();
					}
			};


			scope.finishQ = function(){
				let unAnsweredList = []
				let marks = 0;
				angular.forEach(scope.questions,function(question){
					if(question.m == ""){
						unAnsweredList.push(question);
					}
					else{
						if(question.m == question.a){
							marks+=1;
						}

					}
				})
				if(unAnsweredList.length>0){
					console.log("questions are pending!");
				}else{
					console.log(marks);
					storeService.set('marks',marks);
					$location.path('/result');
				}

			};
			scope.viewSkipped = function(){
				scope.list.skipped = !scope.list.skipped;
				if(scope.list.skipped){
					if(questionListS[i].m != ""){
						scope.nextQ();
					}
				}
			}
		}
	}
	allQuestionsDirective.$inject = ['storeService','$location'];
})();
/*
*
*	@author: smbth
*	@desc  : angularJS quiz app, jhon papa style guide 
* 	 
*
*/
/*
Special requirements:
Disable previous button for 1st Question
Next button for last question must be 'finish' quiz button,from 'finish' go to either quiz result, or a page  that asks the user to direct to skipped questions
*/
/*
Pending implementations:
	muliple controllers
	login with route guards, session storage
*/
(function(){
	angular.module('quizApp',['ngRoute']);
})();

/*
*
*	@author: smbth
*	@desc  : angularJS quiz app, jhon papa style guide 
* 	 
*
*/
(function(){
	angular.module('quizApp',['ngRoute']);
})();

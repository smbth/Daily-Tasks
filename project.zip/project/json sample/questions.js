
var app=angular.module('sample',[]);
  app.controller('myCrtl',['$scope','$http',function($scope,$http)
    {
      $http.get('data.json').then(function(response)
        {
          $scope.datajson = response.data;
          console.log($scope.datajson);
        });
      }]);

/*
* @des: to do App, Architecture reworked and implemented in jquery
* @author: sambath
*to do : highlight selected option in menu, re implement the display function using jquery
*/

todoArray=[];
// Menu Flag Values: A-All tasks, T-To be done tasks, C-completed tasks
menuFlag = 'T'; 

$(document).ready(function(){
 loadArray();
 display();
});


//jQuery to add a new task
$("#task").change(function(){
	task = $("#task").val();
	$("#task").val("");
	todoArray.push({taskValue:task,status:false});
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
});


// Load the array with JSON content.
function loadArray(){
	todoArray = JSON.parse(localStorage.getItem('todo'));
}

// Refresh Function
function refresh(){
	$("#content").html("");
}


// jquery filter function for displaying all tasks
$("#all").click(function(){
	menuFlag = 'A';
	display();
	// display('A');
});

//jquery filter function for displaying  tasks to do
$("#todo").click(function(){
	menuFlag = 'T'
	display();
});

// jquery filter function for displaying  completed tasks
$("#comp").click(function(){
	menuFlag = 'C';
	display();
});




//Display Function
function display(){
	refresh();
	for(let i = 0;i < todoArray.length;i++){
		var list         = document.createElement("li");
		// list = $(document.createElement('li'));
		var span         = document.createElement("span");
		// span = $(document.createElement('span'));
		var statusButton = document.createElement("button");
		// statusButton = $(document.createElement('button'));
		var deleteButton = document.createElement("button");
		// deleteButton = $(document.createElement('button'));
		statusButton.setAttribute("onclick","changeStatus("+i+")");
		// statusButton.attr("onclick","changeStatus("+i+")");
		deleteButton.setAttribute("onclick","deleteTask("+i+")");
		// deleteButton.attr("onclick","deleteTask("+i+")");
		deleteButton.setAttribute("title","Delete!");
		// deleteButton.attr("title","Delete!");
		deleteButton.innerHTML = "&#9747";
		// deleteButton.html("&#9747");

		if(menuFlag == 'T' || menuFlag == 'A'){
			if (todoArray[i].status === false){
				statusButton.innerHTML = "&#10003;";
				statusButton.setAttribute("title","Done!");
				displayList(list,span,statusButton,deleteButton,i);
			}
		}

		if(menuFlag == 'C' || menuFlag == 'A'){
			if (todoArray[i].status === true) {
				statusButton.innerHTML = "&#8634;"
				statusButton.setAttribute("title","Redo!");
				span.setAttribute("class","strikedText");
				displayList(list,span,statusButton,deleteButton,i);
			}
		}
	}
}

//Append list elements to the content div
function displayList(list,span,statusButton,deleteButton,i){
	list.append(statusButton);
	span.append(todoArray[i].taskValue);
	list.append(span);
	list.append(deleteButton);
	$("#content").append(list);
}

//Status Changer,trigerred by onclick
function changeStatus(i){
	if (todoArray[i].status === false){
		todoArray[i].status = true;
	}
	else{
		todoArray[i].status = false;
	}
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}

// Task Deleter, trigerred by onclick
function deleteTask(i){
	todoArray.splice(i,1);
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}


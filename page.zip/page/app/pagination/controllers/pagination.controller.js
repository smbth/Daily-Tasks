/*
 *@name  :
 *@desc  :
 *@author: sambath
 */
 (function(){
 	angular
 	.module('myApp')
 	.controller('paginationController',controller);
 	function controller($scope){
 		// vm - view model
 		var vm = this;	
 	}
 	controller.$inject = ['$scope']
 })();
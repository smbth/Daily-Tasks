(() => {
    angular.module('formApp')  
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider
        .when('/login', {
            template: '<login-directive></login-directive>',
            permission: true
        })
        .when('/tableview', {
            templateUrl: 'app/templates/homeTemplate.html'
        })
        .when('/adduser', {
            template: '<div register-directive = ""></div>'
        })
        .otherwise({
            redirectTo: '/login'
        })
    }]);
})();


angular.module('quizApp', ['ngRoute']);
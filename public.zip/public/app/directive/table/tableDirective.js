(() => {
    angular.module('formApp')
    .directive('userListDirective', ['getUserFactory', 'registerUserFactory', 'exchgData', '$location', function(getUserFactory, registerUserFactory, exchgData, $location) {
        return {
            link : link,
            templateUrl: 'app/directive/table/tableTemplate.html'
        }
        function link(scope, element, attr) {
            scope.userList = getUserFactory.get();
            scope.removeUser = function(id) {
                scope.userList.splice(id, 1);
                registerUserFactory.save(scope.userList);
            }
            scope.updateUser = function(id) {
                exchgData.set('user', {userList : scope.userList, id : id});
                $location.path('/adduser');
            }
        }
    }]);
})();

    
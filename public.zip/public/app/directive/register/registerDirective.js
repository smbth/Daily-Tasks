(()=> {
    angular.module('formApp')
    .directive('registerDirective', ['registerUserFactory', 'getUserFactory', 'exchgData', '$location', function(registerUserFactory, getUserFactory, exchgData, $location) {
        return {
            link: link,
            templateUrl: 'app/directive/register/registerTemplate.html'
        }
        function link(scope, element, attr) {
            let editUser;
            function init() {
                editUser = exchgData.get('user');
                if(editUser) {
                    scope.userList = editUser.userList;
                    scope.user = editUser.userList[editUser.id];
                    scope.buttonText = 'Update';
                } else {
                    scope.userList = getUserFactory.get();
                    // scope.user = "";
                    scope.buttonText = 'Save';
                }
            }
            init();
            scope.addUser = function(status = false) {
                if(!editUser) scope.userList.push(scope.user);
                if(registerUserFactory.save(scope.userList)) {
                    init();
                    if(status === true) {
                        $location.path('/tableview');
                    }
                }
            }
        }
    }])
    .factory('registerUserFactory', ['getUserFactory', function(getUserFactory) {
        let userList = getUserFactory.get();
        return {
            save: function(user) {
                if(Array.isArray(user)) {
                    userList = user;
                } else {
                    userList.push(user);
                }
                localStorage.setItem('userList', JSON.stringify(userList));
                return true;
            }
        }
    }]);
})();

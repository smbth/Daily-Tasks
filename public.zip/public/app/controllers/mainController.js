
angular.module('quizApp')
.controller('mainCtrl', function($scope) {
    $scope.greetings = "Hello World!";
});
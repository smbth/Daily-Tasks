var app = angular.module('plunker', []);

app.controller('ParentCtrl', function($scope) {
  $scope.name = "Name from parent";
});

app.controller('ChildCtrl', function($scope) {
  $scope.name = "Name from children";
});
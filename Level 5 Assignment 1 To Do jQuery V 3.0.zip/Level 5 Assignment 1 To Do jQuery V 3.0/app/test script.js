// jquery display function
function display(){
	// $(document.createElement('ul'));
	for(let i = 0;i < todoArray.length;i++){
		
	}

}






//Display Function
function display(){
	// refresh();
	var ulist=document.createElement("ul");
	for(let i = 0;i < todoArray.length;i++){
		var list=document.createElement("li");
		list.setAttribute("align","center");
		var span         = document.createElement("span");
		var statusButton = document.createElement("button");
		var deleteButton = document.createElement("button");
		statusButton.setAttribute("onclick","changeStatus("+i+")");
		deleteButton.setAttribute("onclick","deleteTask("+i+")");
		deleteButton.setAttribute("title","Delete!");
		deleteButton.innerHTML = "&#9747";
		
		if(menuFlag==='A'){
			allbt.setAttribute("class", "bt_active");
			todobt.setAttribute("class", "");
			compbt.setAttribute("class", "");
			if(todoArray[i].status == false){
				statusButton.innerHTML = "&#10003;";
				statusButton.setAttribute("title","Done!");
			}
			else{
				statusButton.innerHTML = "&#8634;";
				statusButton.setAttribute("title","Redo!");
				list.setAttribute("class","strikedText");
			}
			span.append(statusButton);
			span.append(deleteButton);
			list.append(todoArray[i].taskValue);
			list.append(span);
			ulist.append(list);
		}

		if(menuFlag === 'T'){
			allbt.setAttribute("class", "");
			todobt.setAttribute("class", "bt_active");
			compbt.setAttribute("class", "");
			if (todoArray[i].status === false){
				statusButton.innerHTML = "&#10003;";
				statusButton.setAttribute("title","Done!");
				span.append(statusButton);
				span.append(deleteButton);
				list.append(todoArray[i].taskValue);
				list.append(span);
				ulist.append(list);
			}
		}

		if(menuFlag === 'C'){

			allbt.setAttribute("class", "");
			todobt.setAttribute("class", "");
			compbt.setAttribute("class", "bt_active");
			if (todoArray[i].status === true) {
				statusButton.innerHTML = "&#8634;"
				statusButton.setAttribute("title","Redo!");
				list.setAttribute("class","strikedText");
				span.append(statusButton);
				span.append(deleteButton);
				list.append(todoArray[i].taskValue);
				list.append(span);
				ulist.append(list);
			}
		}
	}
	// console.log(ulist);
	refresh();
	document.getElementById("content").append(ulist);
}
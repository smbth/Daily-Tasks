/*
*
*
* @des: to do App, Re-implemented in jquery!.
* @author: sambath
*
*
*/

$(document).ready(function(){
	todoArray = [];
	menuFlag  = 'T'; 
 	loadArray();
	display();
});

//jQuery to add a new task
$("#task").change(function(){
	task = $("#task").val();
	$("#task").val("");
	todoArray.push({taskValue:task,status:false});
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
});

// Load the array with JSON content.
function loadArray(){
	todoArray = JSON.parse(localStorage.getItem('todo'));
}

// Refresh Function
function refresh(){
	$("#content").html("");
}

// jquery filter function for displaying all tasks
$("#all").click(function(){
	menuFlag = 'A';
	display();
});

//jquery filter function for displaying  tasks to do
$("#todo").click(function(){
	menuFlag = 'T'
	display();
});

// jquery filter function for displaying  completed tasks
$("#comp").click(function(){
	menuFlag = 'C';
	display();
});

//Display Function
function display(){
	refresh();
	menuHighlighter();
	for(let i = 0;i < todoArray.length;i++){ 
		var list         = $('<li>');
		var span         = $('<span>');
		var statusButton = $('<button>');
		var deleteButton = $('<button>');
		statusButton.attr("onclick","changeStatus("+i+")");
		deleteButton.attr("onclick","deleteTask("+i+")");
		deleteButton.attr("title","Delete!");
		deleteButton.html("&#9747;");

		if(menuFlag == 'T' || menuFlag == 'A'){
			if (todoArray[i].status === false){
				statusButton.html("&#10003;");
				statusButton.attr("title","Done!");
				displayList(list,span,statusButton,deleteButton,i);
			}
		}

		if(menuFlag == 'C' || menuFlag == 'A'){
			if (todoArray[i].status === true) {
				statusButton.html("&#8634;");
				statusButton.attr("title","Redo!");
				span.attr("class","strikedText");
				displayList(list,span,statusButton,deleteButton,i);
			}
		}
	}
}

//Append list elements to the content div
function displayList(list,span,statusButton,deleteButton,i){
	list.append(statusButton);
	span.append(todoArray[i].taskValue);
	list.append(span);
	list.append(deleteButton);
	$("#content").append(list);
}

// to highlight the selected option from the menu
function menuHighlighter(){
	if(menuFlag == 'A'){
		$("#all").addClass("bt_active ");
		$("#todo, #comp").removeClass("bt_active");
	}

	if(menuFlag == 'T'){
		$("#todo").addClass("bt_active ");
		$("#all, #comp").removeClass("bt_active");
	}

	if(menuFlag == 'C'){
		$("#comp").addClass("bt_active ");
		$("#all, #todo").removeClass("bt_active");
	}
}

//Status Changer,trigerred by onclick
function changeStatus(i){
	if (todoArray[i].status === false){
		todoArray[i].status = true;
	}
	else{
		todoArray[i].status = false;
	}
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}

// Task Deleter, trigerred by onclick
function deleteTask(i){
	todoArray.splice(i,1);
	localStorage.setItem('todo',JSON.stringify(todoArray));
	refresh();
	display();
}

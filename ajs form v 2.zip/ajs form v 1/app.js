	angular.module('formApp',[])
	.controller('formController',['$scope',function($scope){
		// $scope.name= "name";
		$scope.array = [];
		array = JSON.parse(localStorage.getItem('myJSON'));
		console.log(array);
		$scope.submitForm = function(){
			let formObj = {
				name      : $scope.name,
				gender    : $scope.gender,
				telephone : $scope.phone,
				email     : $scope.email,
				password  : $scope.password,
				address   : $scope.address,
				pincode   : $scope.pincode
			}

			array.push(formObj);
		 // console.log(array);
		 localStorage.setItem('myJSON',JSON.stringify(array));
		 // console.log(myJSON);
		 // array = JSON.parse(localStorage.getItem('myJSON'));
		 console.log(array);
		}



	}]);
	//.directive('myFormDirective',['$scope',function($scope){
		// let formObj = {
		// 	name      : $scope.name,
		// 	gender    : $scope.gender,
		// 	telephone : $scope.phone,
		// 	email     : $scope.email,
		// 	password  : $scope.password,
		// 	address   : $scope.address,
		// 	pincode   : $scope.pincode
		// }

		// console.log(formObj);
		// localStorage.setItem('myJSON',JSON.stringify(formObj));
		//var myJSON = JSON.stringify(formObj);
	//}]);

	// localStorage.setItem('todo',JSON.stringify(todoArray));
	//todoArray = JSON.parse(localStorage.getItem('todo'));
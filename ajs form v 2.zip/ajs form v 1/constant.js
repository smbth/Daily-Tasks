// $scope.nameRegEx     = "/^[a-z][a-z ,.'-]+$/i";
// $scope.emailRegEx    = "/^\w+?\.?\w+@{1}\w+\.\w{2,3}\b/i";
// $scope.phoneRegEx    = "/^(\+\d{1,3})?\(?\d{10}\)?\d{3}\d{4}$/";
// $scope.passwordRegEx = "/((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*-+]).{8,10})/"; 
// $scope.pinRegEx      = "/^[1-9][0-9]{5}$/";
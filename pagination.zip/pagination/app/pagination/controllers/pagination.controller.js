/*
 *@name:
 *@desc:
 *@author:
 */
 (function(){
 	angular
 	.module('myApp')
 	.controller('paginationController',controller);
 	function controller($scope,$http){
 		// vm - view model
 		var vm = this;
 		// migrate the below data interaction to a separate service
 		$http({
 		  	 method : 'GET',
 		  	 url    : 'assets/json/data.json'
 			})
 			.then(function successCallback(response){
 				    vm.dataList = response.data.results;
 				    for(let i = 0; i < vm.dataList.length; i++){
 				    	vm.dataList[i].id = (i+1);
 				    }
 		 		 }, function errorCallback(response){
 		  			  vm.message='error';
 		  			  console.log(vm.message);
 		  			}
 		        );
 	}
 	controller.$inject = ['$scope','$http']
 })();
/*
 *@name: 
 *@author:
 *@desc: 
 */
 (function(){
 	angular
 	.module('myApp')
 	.factory('paginationValidationService',service);
 	function service(){
 		var service ={
 			validate : validate
 		};
 		return service;
 		function validate(value,length){
 			if(value >= 1 && value <= length && value%1 === 0 || value === null){
 				// console.log(false);
 				return false;
 			}
 			else{
 				return true;
 			}
 		}
 	}
 })();
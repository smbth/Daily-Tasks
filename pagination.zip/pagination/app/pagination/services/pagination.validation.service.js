/*
 *@name: 
 *@author:
 *@desc: 
 */
 (function(){
 	angular
 	.module('myApp')
 	.factory('paginationValidationService',service);
 	function service(){
 		var service ={
 			validate : validate
 		};
 		return service;
 		function validate(value,length){
 			if(value >= 1 && value <= length && value != null){
 				// console.log("validate true");
 				return true;
 			}
 			else{
 				// console.log("validate false");
 				return false;
 			}
 		}
 	}
 })();
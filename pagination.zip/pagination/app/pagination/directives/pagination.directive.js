/*
 *@name    : pagination directive
 *@desc    : a custom pagination directive
 *@author  : sambath
 *@example : <fs-myapp-pagination></fs-myapp-pagination>
 */

(function(){
	angular
	.module('myApp')
	.directive('fsMyappPagination',directive);
	// paginationService changed to pager
	// validationService changed to validtor
	function directive(pager,validator){
		let directive = {
			link : link,
			templateUrl : `app/pagination/templates/pagination.template.html`,
			restrict : `EA`,
			scope : { config : "=" , id : "@" }
		} 
		return directive;
		function link(scope,element,attrs,ctrl){

			scope.tableData           = [];
			scope.itemsPerPage        = 7;
			scope.currentPage         = 1;
			let pageNumbersPerPage    = 8;

			scope.$watch('config',function(){
				if(scope.config){

					scope.totalPages = Math.ceil(scope.config.length / scope.itemsPerPage);
					scope.$watch('currentPage',function(){
						if(validator.validate(scope.currentPage,scope.totalPages)){
							changePageConfig();
						}						
					});

					var buttons = document.getElementsByClassName("navigation_input");
					buttons[0].addEventListener("keyup",function(event){
						// console.log(scope.itemsPerPage);
						event.preventDefault();
								if(event.keyCode === 13){
										// scope.totalPages = Math.ceil(scope.config.length / scope.itemsPerPage);
										console.log(scope.totalPages);
										if(scope.currentPage > scope.totalPages){
											scope.currentPage = 1;
											// console.log(scope.currentPage);
										}
										changePageConfig();
										scope.$apply();		
								}
					});

					function changePageConfig(){
						// if(scope.currentPage     != null && scope.itemsPerPage != null){
							// console.log(scope.currentPage);
							let pageStartItem     = ((scope.currentPage - 1) * scope.itemsPerPage);
							let pageEndItem       = pageStartItem + scope.itemsPerPage;
							console.log(scope.itemsPerPage);
							console.log(pageStartItem);
							console.log(pageEndItem);
							scope.tableData       = scope.config.slice(pageStartItem,pageEndItem);
							scope.totalPages      = Math.ceil(scope.config.length / scope.itemsPerPage);
							scope.pageNumberArray = pager.setPages(scope.totalPages,pageNumbersPerPage,scope.currentPage);		
						// }
					}			
			    }
			});

			scope.getPrevPage = getPrevPage;
			scope.getNextPage = getNextPage;
			scope.getPage     = getPage;

			function getPage(page){
				scope.currentPage = page;
			}

			function getPrevPage(){
				if(scope.currentPage > 1){
					scope.currentPage--;
				}
			}

			function getNextPage(){
				if(scope.currentPage < scope.totalPages){
					scope.currentPage++;
				}
			}
		}

	}
	directive.$inject = ['paginationService','paginationValidationService'];
})()
/*
 *@name: main app
 *@desc: the app containing the custom directive
 *@author: sambath
*/
(function(){
	angular.module('myApp',[]);
})();
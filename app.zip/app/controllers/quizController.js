 (function(){
	angular.module('quizApp')
	.controller('quizController',quizController);
	function quizController($scope){
		$scope.var = 'this is the quiz app';
	}
	quizController.$inject= ['$scope'];
})();
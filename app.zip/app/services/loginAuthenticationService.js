(function(){
	angular
	.module('quizApp')
	.factory('loginAuthenticateService',loginAuthenticateService);
	function loginAuthenticateService(){
		var service = {
			checkUser: checkUser,
			isLogged: isLogged,
			logout: logout
		};
		return service;
		function checkUser(user){
			if(user.userName === "student" && user.passWord === "key123"){
				let uid = Math.floor((Math.random()*100000000)+1);
				sessionStorage.setItem('sessionData',JSON.stringify({id: uid,name: user.username}))
				return true;	
			}else{
				return false;
			}
		}
		function isLogged(){
			return sessionStorage.getItem('sessionData')?true:false;
		}
		function logout(){
			sessionStorage.clear('sessionData');
		}
	}
})();
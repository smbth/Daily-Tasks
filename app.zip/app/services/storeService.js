// A common service, include in common folder 

(function(){
	angular
	.module('quizApp')
	.factory('storeService',storeService);
	function storeService(){
		let data = {}
		var storageService = {
			get: get,
			set: set,
		}

		return storageService;

		function get(key){
			try{
				return data[key];
			}finally{
				data = {};
			}
		}
		function set(key,value){
			data[key] = value;
		}
	}
})();
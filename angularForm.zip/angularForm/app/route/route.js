(() => {
    angular.module('formApp')  
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider
        .when('/login', {
            template: '<login-directive></login-directive>',
            permission: true
        })
        .when('/tableview', {
            template: `<table-directive></table-directive>`
        })
        .when('/adduser', {
            template: `<form-directive></form-directive>`
        })
        .otherwise({
            redirectTo: '/login'
        })
    }]);
})();

(()=> {
    angular.module('formApp')
    .directive('formDirective', ['setUserFactory', 'getUserFactory', 'exchgData', '$location', function(setUserFactory, getUserFactory, exchgData, $location) {
        return {
            link: link,
            templateUrl: 'app/directive/form/formTemplate.html'
        }
        function link(scope, element, attr) {
            let editUser;
            function reload() {
                editUser = exchgData.get('user');
                if(editUser) {
                    scope.userList = editUser.userList;
                    scope.user = editUser.userList[editUser.id];
                    scope.buttonText = 'Update';
                } else {
                    scope.userList = getUserFactory.get();
                    scope.buttonText = 'Save';
                }
            }
            reload();
            scope.addUser = function(status = false) {
                if(!editUser) scope.userList.push(scope.user);
                if(setUserFactory.save(scope.userList)) {
                    reload();
                    if(status === true) {
                        $location.path('/tableview');
                    }
                }
            }
        }
    }])
    .factory('setUserFactory',function() {
        return {
            save: function(user) {
                userList = user;
                // console.log(userList);
                localStorage.setItem('formJSON', JSON.stringify(userList));
                return true;
            }
        }
    });
})();


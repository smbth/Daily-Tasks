(() => {
    angular.module('formApp')
    .directive('tableDirective', ['getUserFactory', 'setUserFactory', 'exchgData', '$location', function(getUserFactory, setUserFactory, exchgData, $location) {
        return {
            link : link,
            templateUrl: 'app/directive/table/tableTemplate.html'
        }
        function link(scope, element, attr) {
            scope.userList = getUserFactory.get();
            scope.removeUser = function(index) {
                scope.userList.splice(id, 1);
                setUserFactory.save(scope.userList);
            }
            scope.updateUser = function(index) {
                exchgData.set('user', {userList : scope.userList, id : index});
                $location.path('/adduser');
            }
        }
    }]);
})();


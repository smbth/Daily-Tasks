const http = require('http');
const fs = require('fs');
const url = require('url');

function serveFile(fileName, res) {
    fs.readFile(fileName, null, function(err, data) {
        if(err) {
            res.writeHead(404);
            res.write('File Not Found!');
            res.end();
        } else {
            res.write(data);
            res.end();
        }
    });
}

function requestHandler(req, res) {
    const path = url.parse(req.url).pathname;
    res.writeHead(200, {'Content-Type' : 'text/html'});
    switch(path) {
        case '/' : {
            serveFile('index.html', res);
            break;
        }
        case '/services' : {
            serveFile('services.html', res);
            break;
        }
        default : {
            res.writeHead(404);
            res.write('File Not Found!');
            res.end();
        }
    }
}

http.createServer(requestHandler).listen('3000', console.log('Server listening...'));
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-my-form',
  templateUrl: './my-form.component.html',
  styleUrls: ['./my-form.component.css']
})
export class MyFormComponent implements OnInit {

  constructor(private fb: FormBuilder) { }
// Validators.pattern(``)
  regForm =  this.fb.group({
  	 name     : ['',[Validators.required,Validators.pattern(/^[a-z][a-z ,.'-]+$/i)]],
  	 email    : ['',[Validators.required,Validators.pattern(/^\w+?\.?\w+@{1}\w+\.\w{2,3}\b/i)]],
  	 gender   : ['m',[Validators.required]],
  	 phone    : ['',[Validators.required,Validators.pattern(/^\d{10}\b/)]],
  	 address  : ['',[Validators.required]],
  	 password : ['',[Validators.required,Validators.pattern(/((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*-+]).{6,20})/)]],
  	 confirm  : ['',[Validators.required,Validators.pattern(/((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*-+]).{6,20})/)]]
     },{
        validator: this.mustMatch('password', 'confirm')
    });
// length between 6 and 20,any Small,Caps,Special Chara, Num atleat once
  onSubmit(){
  	if(this.regForm.invalid){
  		return;
  	} else{
  		alert("Successful!")
  	}
  }
  mustMatch(controlName: string, matchingControlName: string){
  	return (formGroup:FormGroup)=>{
  		const control         = formGroup.controls[controlName];
  		const matchingControl = formGroup.controls[matchingControlName];
  		if(control.value != matchingControl.value){
  			matchingControl.setErrors({mustMatch:true});
  			console.log("Not Matching!");
  		}else{
  			matchingControl.setErrors(null);
  			console.log("Matching!");
  		}
  	}
  }
  // export function MustMatch(controlName: string, matchingControlName: string) {
  //     return (formGroup: FormGroup) => {
  //         const control = formGroup.controls[controlName];
  //         const matchingControl = formGroup.controls[matchingControlName];

  //         if (matchingControl.errors && !matchingControl.errors.mustMatch) {
  //             // return if another validator has already found an error on the matchingControl
  //             return;
  //         }

  //         // set error on matchingControl if validation fails
  //         if (control.value !== matchingControl.value) {
  //             matchingControl.setErrors({ mustMatch: true });
  //         } else {
  //             matchingControl.setErrors(null);
  //         }
  //     }
  // }
  ngOnInit() {
  	console.log("Hello World!");
  }

}

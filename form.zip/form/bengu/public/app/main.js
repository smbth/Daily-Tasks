/*
* @auther : Arun lalithambaran
* @Description : Main app script for API-Tester
*/
(() => {
    let app = angular.module('adminPanel', ['ngRoute']);
    app.controller('mainContr', function($scope) {
        $scope.greetings = 'Hello World!';
    });
    
    app.config(function($routeProvider) {
        $routeProvider
        .when('/login', {
            template: '<login-directive></login-directive>'
        })
        .when('/userhome', {
            template: '<h1>User Home</h1>'
        })
        .otherwise({
            redirectTo: '/login'
        })
    });
    app.factory('authenticate', function() {
        let status = {
            valid: false
        }
        return {
            validate: function(login) {
                if(login.username === 'arun' && login.password === '5851') {
                    status.valid = true;
                }
                return status;
            }
        }
    });

    app.directive('loginDirective', ['authenticate', '$location', function(authenticate, $location) {
        return {
            link: link,
            templateUrl: 'app/directive/loginTemplate.html'
        }
        function link(scope, element, attr) {
            scope.login = {
                username: '',
                password: ''
            }
            scope.auth = function() {
                if(authenticate.validate(scope.login).valid) {
                    $location.path('/userhome');
                } else {
                    console.log('Invalid user....');
                }
            }
        }
    }]);
})();

app.factory('authentication',function(){
	let loginStatus = false;
	return{
		validate: function(user){
			console.log('validation about to start');
			if(user.userId ===  "sam" && user.password === "1234567"){
				loginStatus = true;
				console.log("successful authentication!")
			}
			return loginStatus;
		}
	};
});
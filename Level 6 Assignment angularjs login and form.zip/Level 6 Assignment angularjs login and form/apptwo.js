// function myFunction(){
// 	alert("hello world");
// }
app.controller('formCtrl',function($scope){
	$scope.myVar = "Hello World!";
});
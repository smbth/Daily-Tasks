app.directive('formDir',function(){
	return{
		template: 'This is from form directive!!'
		// templateUrl: loginTemplate.html
	};
});
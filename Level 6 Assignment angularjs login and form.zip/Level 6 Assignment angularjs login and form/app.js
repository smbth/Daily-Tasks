let app = angular.module('myApp',['ngRoute']);
let newApp = angular.module('newApp',['app']);
app.config(function($routeProvider){
	$routeProvider
	.when('/login',{
		template: `<log-in></log-in>`
	})
	.when('/dashBoard',{
		template: `You logged in Successfully`
	})
	.otherwise({
		template:``
	});
});

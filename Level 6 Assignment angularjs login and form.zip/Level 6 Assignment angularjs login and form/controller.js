app.controller('formCtrl',function($scope){
	$scope.myVar = value;
});
// newApp.controller('subCtrl',function($scope){
// 	$scope.newVar = 100000;
// })
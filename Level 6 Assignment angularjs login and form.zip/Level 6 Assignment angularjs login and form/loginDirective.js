// app.factory('authentication',function(){
// 	let loginStatus = false;
// 	return{
// 		validate: function(user){
// 			console.log('validation about to start');
// 			if(user.userId ===  "sam" && user.password === "1234567"){
// 				loginStatus = true;
// 			}
// 			return loginStatus;
// 			loginStatus = false;
// 		}
// 	}
// });

app.directive('logIn',['authentication','$location',function(auth,$location){
	console.log('log in running');
	return{
		link: validator,
		templateUrl: 'loginTemplate.html'
	}

	function validator(scope, element, attr){
		scope.user = {
			userId:'',
			password: ''
		}
		scope.checkUser = function(){
			console.log('submit button clicked');
			if(auth.validate(scope.user)){
				$location.path('/dashBoard');
			}
			else{
				console.log('Invalid User!');
			}

		}
	}
}]);
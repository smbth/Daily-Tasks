(() => {
    angular.module('neptune', []);
})();
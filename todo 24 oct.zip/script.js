var myApp =angular.module("todo",[]);

myApp.controller("cntrlR", function($scope){

	// Must use a wrapper object, otherwise "activeItem" won't work
	$scope.states            = {};
	$scope.states.activeItem = 'all';
	// array of objects to store tasks and their status
	$scope.taskList          = [];
	if(localStorage.getItem('localTaskList')!=null){
		$scope.taskList = JSON.parse(localStorage.getItem('localTaskList'));
	}

	// Adding new task
	$scope.addTask = function(){
		$scope.taskList.push({value:$scope.taskValue,status:false});
		$scope.taskValue="";
		$scope.saveList();
		// $scope.orderBy($scope.flag);
	};

	// changing the status of a task
	$scope.changeStatus = function(i){
		$scope.taskList[i].status = !$scope.taskList[i].status;
		// console.log(i);
		$scope.checkBoxStatus = $scope.taskList[i].status;
		$scope.saveList();
		// console.log($scope.checkBoxStatus);
		// $scope.checkedStatus = $scope.taskList[i].status;

		// $scope.orderBy($scope.flag);
	};

	// deleting a task
	$scope.deleteTask = function(i){
		$scope.taskList.splice(i,1);
		$scope.saveList();
		// $scope.orderBy($scope.flag);
	};

	// saving the task list to JSON
	$scope.saveList = function(){
		localStorage.setItem('localTaskList',JSON.stringify($scope.taskList));
		$scope.taskList = JSON.parse(localStorage.getItem('localTaskList'));
	};

	// filter function
	$scope.orderBy = function(f){
		$scope.flag = f;
		if(f === false){
			$scope.states.activeItem = 'do';
		}

		else if(f === true){
			$scope.states.activeItem = 'completed';
		}
		else{
			$scope.states.activeItem = 'all';
		}
	};

	// $scope.checkedStatus(i){
	// 	return $scope.taskList[i].status;
	// }
});

// child controller
// myApp.controller("childCtrlR",function($scope){
// 	// $scope.checkBoxStatus = $scope.taskList[i].status;
// 	console.log(checkBoxStatus);
// });
/*
reset and addSubjects not working properly
*/
(function(){
	angular
	.module('quizApp')
	.directive('selectSubjectDirective',selectSubjectDirective);
	function selectSubjectDirective($location){
		var directive = {
			link: subjectLink,
			templateUrl: `app/templates/subjectTemplate.html`
		};
		return directive;
		function subjectLink(scope,element,attrs){
			scope.subjects = [
				{'name':'Computing'},
				{'name':'Physics'},
				{'name':'Mathematics'},
				{'name':'Chemistry'},
				{'name':'Biology'},
				{'name':'History'},
				{'name':'Geography'},
				{'name':'Law'}
			];
			var subjectArray = [];
			  var selectedSubjects = {};
			  scope.formData = { selectedSubjects: selectedSubjects };
			  
			  scope.checkboxChanged = function() {
			    scope.someSelected = Object.keys(selectedSubjects).some(function(key) {
			      return selectedSubjects[key];
			    });
			  };

			  scope.addSubject = function(){
			        angular.forEach(scope.subjects,function(subject){
			           if(selectedSubjects[subject.name]){
			            subjectArray.push(subject.name);
			            console.log(subjectArray);
			            $location.path('/allQuestions');
			           }
			        });
			  };

			  scope.reset = function(){
			  	angular.forEach(scope.subjects,function(subject){
				  	if(selectedSubjects[subject.name]){
				  		selectedSubjects[subject.name] = false;
				  	}	
			  	});
			  	scope.someSelected = false;

			  };
		}
	}
	selectSubjectDirective.$inject = ['$location'];

})();